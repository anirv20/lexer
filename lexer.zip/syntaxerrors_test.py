# T-603-THYD Compilers
# Project: Test driver for lexer
#
"Hello"
"Helló"
"Hell\o"
def _hello9():
    a = 123+2421*3242//22-123
    if 1 == 1 and True and not False and True not in None:
      print(a)
    elif 1 != 2:
      "Hello"
   hello
_hello9((a) -> b)
<><=>===!==
091
