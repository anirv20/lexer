# Test

"Hello"
def _hello9():
    a = 123+2421*3242//22-123
    if 1 == 1 and True and not False and True not in None:
      print(a)
    elif 1 != 2:
      "H\"e\\ll\no\t"
    a = 0
+-*//%<><=>===!==()[],.:->

False None True and as assert async await break class continue def del elif else,
except finally for from global if import in is lambda nonlocal not or pass raise return,
try while with yield